package com.fieb.aula.metodoexterno;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnSomar,btnMedia,btnSair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inicializar();

        btnSomar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent abrirActivitySoma=new Intent(getApplicationContext(),JavaSomar.class);
                startActivity(abrirActivitySoma);
            }
        });

        btnSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void inicializar() {
        btnSomar=findViewById(R.id.btnSomar);
        btnMedia=findViewById(R.id.btnMedia);
        btnSair=findViewById(R.id.btnSair);
    }
}