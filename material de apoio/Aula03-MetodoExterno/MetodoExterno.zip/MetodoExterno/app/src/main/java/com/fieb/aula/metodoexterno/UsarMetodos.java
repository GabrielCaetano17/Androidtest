package com.fieb.aula.metodoexterno;

import android.content.Context;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.Toast;

public class UsarMetodos {
    public static String somar(double valor1,double valor2){
        return String.valueOf(valor1+valor2);
    }

    public static void alertaErro(EditText obj,String s){
        obj.setError(s);
        obj.requestFocus();
    }

public static void alertaToastCustomizado(String info, Context context){
    Toast toast = Toast.makeText(context,info,Toast.LENGTH_LONG);
    toast.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL,0,0);
toast.show();
    }


}
