package com.fieb.aula.metodoexterno;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class JavaSomar extends AppCompatActivity {

    EditText edtValor1, edtValor2;
    Button btnCalcular, btnVoltarSomar;
    TextView tvSoma;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_java_somar);

        inicializar();

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double valor1 = Double.parseDouble(edtValor1.getText().toString());
                    double valor2 = Double.parseDouble(edtValor2.getText().toString());
                    String resultado = UsarMetodos.somar(valor1,valor2);
                    tvSoma.setText("Soma: "+resultado);
                } catch (Exception err) {
                    UsarMetodos.alertaToastCustomizado("Valor em branco", getApplicationContext());
                }
            }
        });

        btnVoltarSomar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void inicializar() {
        edtValor1 = findViewById(R.id.edtValor1);
        edtValor2 = findViewById(R.id.edtValor2);
        btnCalcular = findViewById(R.id.btnCalcular);
        btnVoltarSomar = findViewById(R.id.btnVoltarSomar);
        tvSoma = findViewById(R.id.tvSoma);
        edtValor1.requestFocus();
    }
}