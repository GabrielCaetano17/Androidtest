package com.fieb.aula.usuariosenha.api;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.fieb.aula.usuariosenha.R;
import com.fieb.aula.usuariosenha.controller.PedidoController;
import com.fieb.aula.usuariosenha.model.PedidoModel;
import com.fieb.aula.usuariosenha.view.ItensDoPedido;
import com.fieb.aula.usuariosenha.view.Principal;

import java.util.List;

public class PedidoAdapter extends RecyclerView.Adapter<PedidoAdapter.ViewHolder> {
    @NonNull

    public List<PedidoModel> listPedido;
    public Context aContext;

    PedidoController pedidoController;

    public PedidoAdapter(List<PedidoModel> pedido, Context context) {
        listPedido = pedido;
        aContext = context;
    }

    @Override
    public PedidoAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        Context context = parent.getContext();

        LayoutInflater inflater = LayoutInflater.from(context);
        View linhaView = inflater.inflate(R.layout.linhas_bolos, parent, false);
        ViewHolder viewHolder = new ViewHolder(linhaView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull PedidoAdapter.ViewHolder holder, int position) {
        PedidoModel objLinha = listPedido.get(position);

        TextView tvIdBolo = holder.rvIdBolo;
        tvIdBolo.setText(String.valueOf(objLinha.getId()));

//        ===================

        ImageView tvImagemBolo = holder.rvImagemBolo;

        Resources resources = aContext.getResources();
        int idR = resources.getIdentifier(objLinha.getFotoBolo(), "drawable", aContext.getPackageName());
        tvImagemBolo.setImageResource(idR);

//        =============

        TextView tvNomeBolo = holder.rvNomeBolo;
        tvNomeBolo.setText(objLinha.getNomeBolo());

        TextView tvDescricao = holder.rvDescricaoBolo;
        tvDescricao.setText(objLinha.getDescricaoBolo());


        TextView tvPreco = holder.rvPrecoBolo;
        tvPreco.setText(objLinha.getPrecoBolo());
    }

    @Override
    public int getItemCount() {
        return listPedido.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView rvIdBolo;
        public ImageView rvImagemBolo;
        public TextView rvNomeBolo;
        public TextView rvDescricaoBolo;
        public TextView rvPrecoBolo;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            rvIdBolo = itemView.findViewById(R.id.tvIdBolo);
            rvImagemBolo = itemView.findViewById(R.id.ivBolo);
            rvNomeBolo = itemView.findViewById(R.id.tvNomeBolo);
            rvDescricaoBolo = itemView.findViewById(R.id.tvDescricaoBolo);
            rvPrecoBolo = itemView.findViewById(R.id.tvPrecoBolo);

            rvImagemBolo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    Auxiliares.alert(aContext,"Bolo de " + rvNomeBolo.getText().toString());

                    Intent intent = new Intent(aContext, ItensDoPedido.class);

                    int position = getAdapterPosition();
                    intent.putExtra("chave", rvIdBolo.getText().toString()+"-"+rvNomeBolo.getText().toString());
//                    intent.putExtra("chave", String.valueOf(id.getId()));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    aContext.startActivity(intent);
                }
            });
        }
    }
}
