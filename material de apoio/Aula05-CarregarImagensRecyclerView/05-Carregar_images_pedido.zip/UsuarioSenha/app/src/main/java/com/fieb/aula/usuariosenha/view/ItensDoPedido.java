package com.fieb.aula.usuariosenha.view;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.fieb.aula.usuariosenha.R;

public class ItensDoPedido extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_itens_do_pedido);

        Bundle extra = getIntent().getExtras();

        if (extra != null) {
            //Se houver id, então
            setTitle( extra.getString("chave"));

            //Informa o Id para alteracao no set
            /*produto = new Produto();
            produto.setId(Integer.parseInt(tvIdProduto.getText().toString()));
*/
            //Preencher com o dados conforme id
//            populaDados(idControle);
        }

    }
}