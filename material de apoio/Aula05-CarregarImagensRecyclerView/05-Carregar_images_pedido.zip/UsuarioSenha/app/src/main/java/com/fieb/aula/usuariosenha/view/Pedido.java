package com.fieb.aula.usuariosenha.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

import com.fieb.aula.usuariosenha.R;
import com.fieb.aula.usuariosenha.api.PedidoAdapter;
import com.fieb.aula.usuariosenha.controller.PedidoController;
import com.fieb.aula.usuariosenha.model.PedidoModel;

public class Pedido extends AppCompatActivity {

    PedidoController pedidoController;

    List<PedidoModel> pedidos; //Linha dos dados
    RecyclerView recyclerView; //Objetos receberá os dados montados

    PedidoAdapter pedidoAdapter;

//    Button btnFecharPedido;
//    TextView tvTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedido);

        recyclerView = findViewById(R.id.rvPedidos);

//        btnFecharPedido=findViewById(R.id.btnFecharPedido);
//        tvTotal=findViewById(R.id.tvTotal);

        carregaLista();

    }

    private void carregaLista() {
        pedidoController = new PedidoController();

        pedidos = pedidoController.consultaBolo(getApplicationContext());

        pedidoAdapter = new PedidoAdapter(pedidos,getApplicationContext());
//        clienteAdapter=new ClienteAdapter(clientes,getApplicationContext(), contextMenu);


        //Add a Linha onde está no LinearLayout
//        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(pedidoAdapter);
    }

    public void voltarTelaPedido(View view) {
        finish();
    }

    public void finalizaPedido(View view) {

    }
}