package com.fieb.aula.usuariosenha.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.fieb.aula.usuariosenha.R;

public class Principal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
    }
}